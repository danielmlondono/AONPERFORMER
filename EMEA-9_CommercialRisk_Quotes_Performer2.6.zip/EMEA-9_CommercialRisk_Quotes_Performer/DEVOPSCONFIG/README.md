# Comment
Put in this folder all csv files that are needed for Azure DevOps pipeline.