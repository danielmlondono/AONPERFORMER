# Comment
Each Aon Robotic Framework folder 'FRAMEWORK', 'PROCESS', 'SUPPORT', 'SCRIPTS', 'DEVOPSCONFIG' and 'TEST' contains README.md file containing brief information of each folder purpose.

# Useful links
- ARF documentation: https://confluence.ie.aon.bz/display/AC/Aon+Robotic+Framework
- Azure DevOps Aon documentation: https://confluence.ie.aon.bz/pages/viewpage.action?pageId=59818094
- Project documentation paths: <paste url's here>
- Project config paths: <paste url's here>

# Exceptions - code review
Put here in points information about code review exceptions agreed with Aon CoE.