# Comment
Put in this folder all external scripts launched by the bot